package com.mayur.demo.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessagePublisher {
    @Autowired
    private JmsTemplate jmsTemplate;

    public void publishEvent(String operation, String entityName, String details) {
        String message = String.format("Operation: %s, Entity: %s, Details: %s", operation, entityName, details);
        jmsTemplate.convertAndSend("audit-queue", message);
    }
}
