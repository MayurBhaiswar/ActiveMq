package com.mayur.demo.service;

import com.mayur.demo.exception.ResourceNotFoundException;
import com.mayur.demo.model.Product;
import com.mayur.demo.repository.ProductRepository;
import com.mayur.demo.utils.MessagePublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private MessagePublisher messagePublisher;

    public Product createProduct(Product product) {
        Product savedProduct = productRepository.save(product);
        messagePublisher.publishEvent("CREATE", "Product", savedProduct.toString());
        return savedProduct;
    }

    public Product updateProduct(Long id, Product product) {
        Product existingProduct = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
        existingProduct.setName(product.getName());
        existingProduct.setDescription(product.getDescription());
        existingProduct.setPrice(product.getPrice());
        Product updatedProduct = productRepository.save(existingProduct);
        messagePublisher.publishEvent("UPDATE", "Product", updatedProduct.toString());
        return updatedProduct;
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
        messagePublisher.publishEvent("DELETE", "Product", "Deleted product with ID: " + id);
    }
    public Product getProduct(Long id) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));;
        messagePublisher.publishEvent("GET BY ID", "Product", "GET product with ID: " + id);
        return product;
    }


    public List<Product> getAllProducts() {
        List<Product> productList= productRepository.findAll();
        messagePublisher.publishEvent("GET ALL", "Product", "Find all product." );
        return productList;
    }
}
