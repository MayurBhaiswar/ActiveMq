package com.mayur.demo.utils;

import com.mayur.demo.model.AuditLog;
import com.mayur.demo.repository.AuditLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class MessageSubscriber {
    @Autowired
    private AuditLogRepository auditLogRepository;

    @JmsListener(destination = "audit-queue")
    public void consumeMessage(String message) {
        AuditLog log = new AuditLog();
        log.setOperation(message.split(",")[0].split(": ")[1]);
        log.setEntityName(message.split(",")[1].split(": ")[1]);
        log.setDetails(message.split(",")[2].split(": ")[1]);
        log.setTimestamp(LocalDateTime.now().toString());
        auditLogRepository.save(log);
    }
}
