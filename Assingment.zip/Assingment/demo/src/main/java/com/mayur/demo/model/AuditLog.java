package com.mayur.demo.model;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "audit_logs")
public class AuditLog extends BaseEntity {
    private String operation;
    private String entityName;
    private String details;
    private String timestamp;
}
