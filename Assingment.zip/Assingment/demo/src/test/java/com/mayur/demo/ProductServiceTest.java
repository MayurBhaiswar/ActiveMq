package com.mayur.demo;

import static org.mockito.Mockito.*;

import com.mayur.demo.model.Product;
import com.mayur.demo.repository.ProductRepository;
import com.mayur.demo.service.ProductService;
import com.mayur.demo.utils.MessagePublisher;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductServiceTest {
    @Mock
    private ProductRepository productRepository;

    @Mock
    private MessagePublisher messagePublisher;

    @InjectMocks
    private ProductService productService;

    @Test
    public void testCreateProductSuccess() {
        Product product = new Product();
        product.setName("Test Product");

        when(productRepository.save(product)).thenReturn(product);

        Product createdProduct = productService.createProduct(product);

        verify(productRepository, times(1)).save(product);
        verify(messagePublisher, times(1)).publishEvent(anyString(), anyString(), anyString());
    }
}
